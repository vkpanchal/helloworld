name="Eelcome to india";
print("Value of Name",name);
print(name.upper());
print("Show lower case",name.lower());
print("Show center value",name.center(100));

print(name[1:5]);
print("Show first character capatal",name.capitalize());
print("Show Length Fun",len(name));
print("Show Length Fun",len(name));
print("Show end with",name.endswith("india"));
print("Show index of with",name.index('t'));
print("Show is lower of with",name.islower());
name1="WEL";
print("Show is upper of with",name1.isupper());
name2="Raj";
title="Gup";
print(name2.join(title));
n1="Welcome";
print(n1.replace('W','k'));



	