name1="{} and {}".format("Rajesh","Kunal","Sumit")
print(name1);