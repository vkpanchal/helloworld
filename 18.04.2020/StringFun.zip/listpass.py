name=["Raj","Rohan","Vikash","Sumit","Amit","Ankit"]
for n in name:
 if (n == "Vikash"):
    pass
 print(n);
