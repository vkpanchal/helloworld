for x in range(10):
    if (x == 5):
        break
    print(x)
