name="Python"
for n in name:
 if (n == 'h'):
    continue
 print(n);